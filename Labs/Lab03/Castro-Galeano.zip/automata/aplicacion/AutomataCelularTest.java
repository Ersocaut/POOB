package aplicacion;



import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class AutomataCelularTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AutomataCelularTest
{
    /**
     * Default constructor for test class AutomataCelularTest
     */
    public AutomataCelularTest()
    {
    }

    @Test
    public void deberiaMorirLaCelulaDeLaIzquierda(){
        AutomataCelular au=new AutomataCelular();
        au.ticTac();
        assertFalse(au.getElemento(3,5).isVivo());
        assertFalse(au.getElemento(3,6).isVivo());
    }

    @Test
    public void DeberianMorirLasCelulas(){
        AutomataCelular au=new AutomataCelular();
        au.ticTac();
        assertFalse(au.getElemento(1,1).isVivo());
        assertFalse(au.getElemento(2,2).isVivo());
        
    }
    
    @Test
    public void DebianEstarVivas(){
        AutomataCelular au=new AutomataCelular();
        assertTrue(au.getElemento(1,1).isVivo());
        assertTrue(au.getElemento(2,2).isVivo());
    }
    
    
    @Test
    public void DebianEstarMuertas(){
        AutomataCelular au=new AutomataCelular();
        au.ticTac();
        au.ticTac();
        au.ticTac();
        assertFalse(au.getElemento(1,1).isVivo());
        assertFalse(au.getElemento(2,2).isVivo());
    }
    
    @Test
    public void DeberiaPasarelPrimerTicTac(){
        AutomataCelular au= new AutomataCelular();
        au.ticTac();
        assertTrue(au.getElemento(19,1) instanceof Barrera);
        assertFalse(au.getElemento(19,1).isVivo());
        assertTrue(au.getElemento(1,19) instanceof Barrera);
        assertFalse(au.getElemento(1,19).isVivo());
    }
    
    @Test
    public void DeberiaPasarelSegunodoTicTac(){
        AutomataCelular au= new AutomataCelular();
        au.ticTac();
        au.ticTac();
        assertTrue(au.getElemento(19,1) instanceof Barrera);
        assertFalse(au.getElemento(19,1).isVivo());
        assertTrue(au.getElemento(1,19) instanceof Barrera);
        assertFalse(au.getElemento(1,19).isVivo());
    }
    
    @Test
    public void DeberiaPasarelTerceroTicTac(){
        AutomataCelular au= new AutomataCelular();
        au.ticTac();
        au.ticTac();
        au.ticTac();
        assertTrue(au.getElemento(19,1) instanceof Barrera); // a=[]; a is []
        assertFalse(au.getElemento(19,1).isVivo());
        assertTrue(au.getElemento(1,19) instanceof Barrera);
        assertFalse(au.getElemento(1,19).isVivo());
    }
}


